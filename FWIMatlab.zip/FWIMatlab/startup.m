addpath([pwd '/FWI']);
addpath([pwd '/Examples']);
addpath([pwd '/Plotting']);
