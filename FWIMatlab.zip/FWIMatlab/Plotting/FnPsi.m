%%  Draw psi and phi 

obj48i=zeros(2500,1);%(1251,1);
phi48i=zeros(2500,1);%(1251,1);


%fprintf('Progress:\n');
%fprintf(['\n' repmat('.',1,100) '\n\n']);

% t0=tic;
% for a=0:1:1250
% [mw, hist, error]=FWIOnePixel(m, model,[1250-a 1250 1250+a], 0, m0, 1e-6, 100);
% obj(a+1)=ObjFn(mtrue, mw, 0,0, 0);
% phi(a+1)=hist(end,2); 
% fprintf('\b|\n');
% end 
% toc(t0)

t0=tic;
for a=0:1:2500
[mw, hist, error]=FWIOnePixel(m, model,[a], 0, m0, 1e-16, 100);
obj48i(a+1)=ObjFn(mtrue, mw, 0,0, 0);
phi48i(a+1)=hist(end,2); 
a
end 
toc(t0)



figure; 
plot(0:2500, obj48i, 'linewidth', 2);
title('\psi', 'fontsize', 16)
xlabel('Sensor position', 'fontsize', 14)

figure; 
plot(0:2500, phi48i, 'linewidth', 2);
title('\phi', 'fontsize', 16)
xlabel('Sensor position', 'fontsize', 14)



% %normal
% for i=0:1:2500
% [mw, hist, error]=FWIOnePixel(m, model,[i], 1e-3, m0, 1e-6, 100);
% %objT19(i+1)=ObjFn(mtrue(ind(1)), mw(ind(1)), 0,0, 0); 
% obja2(i+1)=ObjFn(mtrue, mw, 0,0, 0);
% phia2(i+1)=hist(end,2); 
% i
% end; toc(t0)