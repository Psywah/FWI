

%% Plotting wavefield with multiple sources

% Full wavefield
[Q]=LinearInterpQT(model.zs,model.xs,model.n, model.h); %Source
Ak = getAR(model.f(end),mtrue,model.h,model.n);         %Helmholtz matriz
Uk=Ak\(Q');                                             %Wavefield

Ukk=0;
for j=1:size(Uk,2)
    Ukk=Ukk+Uk(:,j);     % superposition of wavefield from different sources
end

figure
%surf(x,z,reshape(real(Ukk), [101,101]), 'edgecolor', 'interp')
%surf(x,z,reshape(imag(Ukk), [101,101]), 'edgecolor', 'interp')
surf(x,z,reshape(abs(Ukk), [101,101]), 'edgecolor', 'interp')
set(gca,'XDir','reverse')
xlabel('x', 'fontsize', 12)
ylabel('z', 'fontsize', 12)

% Scattered wavefield
A0 = getAR(model.f(end),m0,model.h,model.n); % Helmholtz matriz
U0=A0\(Q');                                  % Background wave

U00=0;
for j=1:size(Uk,2)
    U00=U00+U0(:,j);  % superposition of wavefield from different sources
end

Ud=Ukk-U00;           % scattered wavefield

figure
%surf(x,z,reshape(real(Ud), [101,101]), 'edgecolor', 'interp');
%surf(x,z,reshape(imag(Ud), [101,101]), 'edgecolor', 'interp');
surf(x,z,reshape(abs(Ud), [101,101]), 'edgecolor', 'interp');
set(gca,'XDir','reverse')
xlabel('x', 'fontsize', 12)
ylabel('z', 'fontsize', 12)


%u=reshape(real(Ukk), [101,101]);
%d=reshape(real(Ud), [101,101]);

% u=reshape(imag(Ukk), [101,101]);
% d=reshape(imag(Ud), [101,101]);

u=reshape(abs(Ukk), [101,101]);
d=reshape(abs(Ud), [101,101]);

%plot of wavefield along sensor line
figure
plot(x,u(:,97), 'linewidth', 2)
title('Wavefield at sensor positions', 'fontsize', 14)
xlabel('x', 'fontsize', 14)
ylabel('u(m)', 'fontsize', 14)

%plot of scattered wavefield along sensor line
figure
plot(x,d(:,97), 'linewidth', 2)
title('Scattered wavefield at sensor positions', 'fontsize', 14)
xlabel('x', 'fontsize', 14)
ylabel('u(m)-u(m_0)', 'fontsize', 14)

figure
plot(x,abs(d(:,97)), 'linewidth', 2)
%title('Magnitude at sensor positions', 'fontsize', 14)
xlabel('x', 'fontsize', 14)
ylabel('|u(m)-u(m_0)|', 'fontsize', 14)