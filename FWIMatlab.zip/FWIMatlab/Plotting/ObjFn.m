function psi= ObjFn(m, mw, beta,p, pstar)

%% Psi

% Function file which calculates the objective function plus a penalty 
% regularisation for the sensor optimisation problem

% Inputs: m     = ground truth model,
%         mw    = FWI output model, 
%         beta  = regularisation parameter, 
%         pstar = position after whch reg isnt added 
% Output: value of objective function:
%         psi = 1/2 || m-mw(p)||_^2 + 1/2 beta (p-pstar)_+^2


% Misfit
mis=0.5*norm(m-mw).^2;

% Regularisation
if p>pstar
    reg=0;
else
    reg=0.5*beta*(p-pstar).^2;
end

% Objective fn
psi=mis+reg;




end
